package com.hello.world;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

//import com.hello.world.repository.OrderRepo;
import com.hello.world.repository.ProductRepo;
import com.hello.world.repository.UserRepo;




@RestController
@RequestMapping("/products")
public class HelloController {
	
	//private ProductServiceImp productService = new ProductServiceImp();
	
	@Autowired
	private ProductRepo productRepo;
	@Autowired
	private UserRepo userRepo;
//	@Autowired
//	private OrderRepo orderRepo;
	
	
	@GetMapping("/user")
	public @ResponseBody  Iterable<User> fetchAllUsers(@RequestHeader("username") String authUser) {
		
		if(authUser.equals("varsha")) {
			return userRepo.findAll();
		}
		else {
			throw new ResponseStatusException(HttpStatus.FORBIDDEN); 
		}
		
	}
		
	
	
	
	@PostMapping(path = "/validateUser")
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody String adduser(@RequestHeader("username") String username, @RequestHeader("password") String password) {
			return username;
			
			
//			Integer UserID =  user.getUserID();
//			System.out.println(UserID);
//			Integer s = 1;
//			
//			if(s.equals(UserID))
//			{
//				userRepo.save(user);
//				return "Saved";
//				
//			}
//			else {
//				return "Failed";
//			}
			
	}
	
	
	@GetMapping("/allproducts")
	public @ResponseBody Iterable<Products> fetchProductList() {
		System.out.println("Getting the list of post users");
		//return productService.fetchPostList();
		return productRepo.findAll();	
	}
	
	
//	@RequestMapping(value="/search/{productID}/{season}/{brand}/{color}/{price}/{category}/{date}", method=RequestMethod.GET)
//	public @ResponseBody List<Products> getproduct(
//			@PathVariable("productID") int productID,
//			@PathVariable("season")String season,
//			@PathVariable("brand")String brand,
//			@PathVariable("color")String color,
//			@PathVariable("price")String price,
//			@PathVariable("category")String category,
//			@PathVariable("date")String date
//			)
//	{
//		
////		Products p = new Products();
////		p.setProductID(productID);
////		p.setProduct_name(season);
////		p.setProduct_name(brand);
////		p.setProduct_name(color);
////		p.setProduct_name(price);
////		p.setProduct_name(category);
//		
//		return productRepo.searchProductsByParams(productID,season,brand,color,price,category,date);
//	
//	}
	
	
	
	@PostMapping(value = "/addproduct")
	public @ResponseBody String addproduct(@RequestBody Products product) {
		productRepo.save(product);
			return "Saved";				
	}
	
	@RequestMapping(value="/deleteproduct/{productID}", method=RequestMethod.DELETE)
	public String deletebyID(@PathVariable("productID") int productID) {
		System.out.println("delete method called");
		Products p = new Products();
		p.setProductID(productID);
		productRepo.save(p);	
		return "Deleted";
	}
	@PutMapping("updateproduct/{id}")
	public Optional<Products> updateProduct(@RequestBody Products newProduct, @PathVariable("id") int productID)
	{
		return productRepo.findById(productID)
				.map(oldProd -> {
					oldProd.setProduct_name(newProduct.getProduct_name());
					return productRepo.save(oldProd);
				});
	}
	
	@RequestMapping(value="/purchase_order/{category}/{order_date}", method=RequestMethod.GET)
	public @ResponseBody List<Products> getproduct(
			@PathVariable("category") String category,
			@PathVariable("order_date") String date)
	{
		
		return productRepo.searchPurchseOrderByParams(category, date);
	}
	
	
}