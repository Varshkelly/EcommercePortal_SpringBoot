package com.hello.world;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.transaction.annotation.EnableTransactionManagement;

@Entity
@Table(name ="Products")
@EnableTransactionManagement
public class Products {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column
    private int productID;
    
	@Column
    private String product_name;
	@Column
	private String season;
	@Column
	private String brand;
	@Column
	private String category;
	@Column
	private String price;
	@Column
	private String color;
	@Column
	private String date;

	
	public String getSeason() {
		return season;
	}
	public void setSeason(String season) {
		this.season = season;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getCategory() {
			return category;
	}
		public void setCategory(String category) {
			this.category = category;
	}
		public String getPrice() {
			return price;
	}
		public void setPrice(String price) {
			this.price = price;
	}
		public String getColor() {
			return color;
	}
		public void setColor(String color) {
			this.color = color;
	}
		public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

    public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	@Override
	public String toString() {
		return "Products [productID=" + productID + ", product_name=" + product_name + "]";
	} 
    
    
   

}
