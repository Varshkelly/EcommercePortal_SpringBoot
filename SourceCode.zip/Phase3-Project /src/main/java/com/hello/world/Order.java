package com.hello.world;

public class Order {


    private int productID;
    private int orderID;
    private String product_name;
	private String season;
	private String brand;
	private String category;
	private String price;
	private String color;
	private String date;

	
	public String getSeason() {
		return season;
	}
	public void setSeason(String season) {
		this.season = season;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getCategory() {
			return category;
	}
		public void setCategory(String category) {
			this.category = category;
	}
		public String getPrice() {
			return price;
	}
		public void setPrice(String price) {
			this.price = price;
	}
		public String getColor() {
			return color;
	}
		public void setColor(String color) {
			this.color = color;
	}
		public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

    public int getProductID() {
		return productID;
	}
    public int getOrderID() {
		return orderID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	@Override
	public String toString() {
		return "Products [productID=" + productID + ", product_name=" + product_name + "]";
	} 
    

}
