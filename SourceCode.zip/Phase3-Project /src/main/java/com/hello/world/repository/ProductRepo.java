package com.hello.world.repository;

import org.springframework.stereotype.Repository;
import com.hello.world.Order;
import com.hello.world.Products;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
@Transactional
public interface ProductRepo extends JpaRepository<Products, Integer>{
	
//	@Query(value ="select * from Products where productID = :productID and season = :season and brand = :brand and color = :color and price = :price",  nativeQuery = true)
//	List<Products> searchProductsByParams(@Param("productID") int productID, @Param("season") String season, @Param("brand") String brand,
//			@Param("color") String color, @Param("price") String price, @Param("category") String category, @Param("date") String date );
			
			
	
	@Query(value = "select * from product_order po inner join Products p on po.productId = p.productID where p.category = :category and created_date = :created_date", nativeQuery = true)
	List<Products> searchPurchseOrderByParams(@Param("category") String category, @Param("created_date") String created_date);

	
}


