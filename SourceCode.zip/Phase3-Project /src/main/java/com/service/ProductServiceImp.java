package com.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hello.world.Products;

import com.hello.world.repository.ProductRepo;

@Service
public class ProductServiceImp implements ProductService{

	@Autowired
	private ProductRepo productrepo;

	@Override
	public Products saveProducts(Products products) {
		// TODO Auto-generated method stub
		return productrepo.save(products);
	}

	@Override
	public Iterable<Products> fetchProductsList() {
		// TODO Auto-generated method stub
		return productrepo.findAll();
	}

	@Override
	public Products updateProducts(Products products) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int productID) {
		productrepo.deleteById(productID);
	}

}
