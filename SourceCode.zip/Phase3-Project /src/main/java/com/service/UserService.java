package com.service;
import com.hello.world.User;

public interface UserService {
	//save operation 
	User saveUser(User user);
	
	//list operation
	Iterable<User> fetchUserList();
	
	//update Product
	User updateUser(User user);
	
	//delete Product
	void delete(int userID);
}







