package com.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hello.world.User;
import com.hello.world.repository.UserRepo;

@Service
public class UserServiceImp implements UserService{

	@Autowired
	private UserRepo userRepo;

	


	@Override
	public void delete(int userID) {
		// TODO Auto-generated method stub
		userRepo.deleteById(userID);
	}

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return userRepo.save(user);
	}

	@Override
	public Iterable<User> fetchUserList() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
