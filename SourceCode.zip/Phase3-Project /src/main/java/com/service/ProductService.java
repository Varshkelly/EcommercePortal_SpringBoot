package com.service;
import com.hello.world.Products;



public interface ProductService {
	//save operation 
	Products saveProducts(Products products);
	
	//list operation
	Iterable<Products> fetchProductsList();
	
	//update Product
	Products updateProducts(Products products);
	
	//delete Product
	void delete(int productID);

	
}
